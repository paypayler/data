#!/bin/bash

echo "chmod ops"

echo "mv -f ops"

echo "rm -f ops"

echo "touch ops"

echo "end"